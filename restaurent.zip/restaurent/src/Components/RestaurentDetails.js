import React, { Component } from 'react'

export default class RestaurentDetails extends Component {
    render() {
        return (
            <div>
                 <h1>Restaurent Details</h1> 
            </div>
        )
    }
}

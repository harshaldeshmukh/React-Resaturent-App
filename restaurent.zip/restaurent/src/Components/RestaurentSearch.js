import React, { Component } from 'react'

export default class RestaurentSearch extends Component {
    render() {
        return (
            <div>
                 <h1>Restaurent Search</h1> 
            </div>
        )
    }
}
